'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useCart, useTheme, useWishlist } from '@/store'
import { Button } from '@/components/ui/button'
import { Tooltip } from '@/components/ui/tooltip'
import {
  Search,
  ShoppingCart,
  Heart,
  Menu,
  X,
  Moon,
  Sun,
  LogOut,
  LogIn,
  User,
  Settings,
} from 'lucide-react'

export function Header() {
  const { data: session } = useSession()
  const { items: cartItems, getItemCount, saveCartToStorage } = useCart()
  const { items: wishlistItems, saveWishlistToStorage } = useWishlist()
  const { isDark, toggleDarkMode } = useTheme()
  const router = useRouter()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [itemCount, setItemCount] = useState(0)
  const [wishlistCount, setWishlistCount] = useState(0)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (session?.user) {
      setItemCount(getItemCount())
    } else {
      setItemCount(0)
    }
  }, [cartItems, getItemCount, session])

  useEffect(() => {
    if (session?.user) {
      setWishlistCount(wishlistItems.length)
    } else {
      setWishlistCount(0)
    }
  }, [wishlistItems, session])

  // Auto-save cart and wishlist whenever they change
  useEffect(() => {
    if (session?.user) {
      saveCartToStorage()
      saveWishlistToStorage()
    }
  }, [cartItems, wishlistItems, session, saveCartToStorage, saveWishlistToStorage])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/products?search=${encodeURIComponent(searchQuery)}`)
      setSearchQuery('')
    }
  }

  const handleLogout = async () => {
    try {
      await signOut({ 
        redirect: false,
        callbackUrl: '/' 
      })
      router.push('/')
    } catch (error) {
      console.error('[LOGOUT] Error signing out:', error)
      // Still redirect even if there's an error
      router.push('/')
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-white/95 dark:bg-slate-950/95 backdrop-blur-sm">
      <div className="container-custom py-3">
        {/* Mobile Menu Toggle */}
        <div className="flex md:hidden items-center justify-between mb-3">
          <Link href="/" className="text-2xl font-bold text-primary-600">
            🛒 Grocery
          </Link>

          <div className="flex items-center gap-2">
            {/* Wishlist (mobile) */}
            <Link href={session?.user ? '/wishlist' : '/auth/login'}>
              <Button variant="ghost" size="icon" className="relative p-2">
                <Heart size={20} />
                {mounted && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {wishlistCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* Cart (mobile) */}
            <Link href={session?.user ? '/cart' : '/auth/login'}>
              <Button variant="ghost" size="icon" className="relative p-2">
                <ShoppingCart size={20} />
                {mounted && (
                  <span className="absolute -top-1 -right-1 bg-secondary-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Button>
            </Link>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Desktop Header */}
        <div className="hidden md:flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="text-2xl font-bold text-primary-600 flex-shrink-0">
            🛒 Grocery
          </Link>

          {/* Main navigation */}
          <nav className="hidden lg:flex items-center gap-3">
            <Link
              href="/about"
              className="text-sm font-medium text-foreground/80 hover:text-foreground transition-colors"
            >
              About
            </Link>
            <Link
              href="/contact"
              className="text-sm font-medium text-foreground/80 hover:text-foreground transition-colors"
            >
              Contact
            </Link>
          </nav>

          {/* Search Bar */}
          <form
            onSubmit={handleSearch}
            className="flex-1 max-w-md mx-4"
          >
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-slate-900"
              />
              <button
                type="submit"
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
              >
                <Search size={18} className="text-muted-foreground" />
              </button>
            </div>
          </form>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Dark Mode Toggle */}
            <Tooltip content={isDark ? 'Light Mode' : 'Dark Mode'} position="bottom">
              <button
                onClick={toggleDarkMode}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                {isDark ? <Sun size={20} /> : <Moon size={20} />}
              </button>
            </Tooltip>

            {/* Wishlist */}
            <Tooltip content="Wishlist" position="bottom">
              <Link href={session?.user ? '/wishlist' : '/auth/login'}>
                <Button variant="ghost" size="icon" className="relative">
                  <Heart size={20} />
                  {mounted && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                      {wishlistCount}
                    </span>
                  )}
                </Button>
              </Link>
            </Tooltip>

            {/* Cart */}
            <Tooltip content="Shopping Cart" position="bottom">
              <Link href={session?.user ? '/cart' : '/auth/login'}>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart size={20} />
                  {mounted && (
                    <span className="absolute -top-1 -right-1 bg-secondary-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </Button>
              </Link>
            </Tooltip>

            {/* User Menu */}
            {session?.user ? (
              <div className="flex items-center gap-2">
                <Link href="/dashboard">
                  <Button variant="ghost" size="sm">
                    <User size={18} className="mr-2" />
                    Dashboard
                  </Button>
                </Link>
                <Tooltip content="Profile Settings" position="bottom">
                  <Link href="/profile">
                    <button
                      className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <Settings size={20} />
                    </button>
                  </Link>
                </Tooltip>
                <Tooltip content="Logout" position="bottom">
                  <button
                    onClick={handleLogout}
                    className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-destructive"
                  >
                    <LogOut size={20} />
                  </button>
                </Tooltip>
              </div>
            ) : (
              <Link href="/auth/login">
                <Button size="sm" variant="default">
                  <LogIn size={18} className="mr-2" />
                  Login
                </Button>
              </Link>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-border mt-3 pt-3 space-y-3">
            {/* Search for Mobile */}
            <form onSubmit={handleSearch} className="w-full">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-slate-900"
                />
              </div>
            </form>

            {/* Mobile Navigation */}
            <nav className="space-y-2">
              <Link
                href="/products"
                onClick={() => setIsMenuOpen(false)}
                className="block px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
              >
                Products
              </Link>
              <Link
                href="/about"
                onClick={() => setIsMenuOpen(false)}
                className="block px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
              >
                About
              </Link>
              <Link
                href="/contact"
                onClick={() => setIsMenuOpen(false)}
                className="block px-4 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
              >
                Contact
              </Link>
            </nav>

            {/* Mobile Actions */}
            <div className="space-y-2 border-t border-border pt-3">
              <Link href="/wishlist" onClick={() => setIsMenuOpen(false)} className="block">
                <Button className="w-full" variant="outline">
                  <Heart size={18} className="mr-2" />
                  Wishlist ({wishlistCount})
                </Button>
              </Link>

              <Link href="/cart" onClick={() => setIsMenuOpen(false)} className="block">
                <Button className="w-full" variant="outline">
                  <ShoppingCart size={18} className="mr-2" />
                  Cart ({getItemCount()})
                </Button>
              </Link>

              {session?.user ? (
                <>
                  <Link href="/dashboard" onClick={() => setIsMenuOpen(false)} className="block">
                    <Button className="w-full" variant="outline">
                      Dashboard
                    </Button>
                  </Link>
                  <Link href="/profile" onClick={() => setIsMenuOpen(false)} className="block">
                    <Button className="w-full" variant="outline">
                      <Settings size={18} className="mr-2" />
                      Profile
                    </Button>
                  </Link>
                  <Button
                    className="w-full"
                    variant="destructive"
                    onClick={() => {
                      setIsMenuOpen(false)
                      handleLogout()
                    }}
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <Link href="/auth/login" onClick={() => setIsMenuOpen(false)} className="block">
                  <Button className="w-full">Login</Button>
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
